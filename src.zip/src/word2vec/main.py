import os

genre = [ 'Action', 'Adventure', 'Comedy', 'Drama', 'Fantasy', 'Romance' ]

for label in genre:
    print(label)
    os.system("cp {0}.txt utils/datasets/stanfordSentimentTreebank/datasetSentences.txt".format(label))
    os.system("python run.py")
    os.mkdir(label)
    os.system("mv saved_params_1000.npy {0}".format(label))
    os.system("mv saved_state_1000.pickle {0}".format(label))
    # break